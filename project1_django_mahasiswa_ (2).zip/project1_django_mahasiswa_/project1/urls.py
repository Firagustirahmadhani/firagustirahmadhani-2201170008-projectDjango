from django.contrib import admin
from django.urls import path, include
from django.shortcuts import redirect

urlpatterns = [
    path('', lambda request: redirect('/mahasiswa/login/') if not request.user.is_authenticated else redirect('/mahasiswa/')),
    path('admin/', admin.site.urls),
    path('mahasiswa/', include('mahasiswa.urls')),
]
