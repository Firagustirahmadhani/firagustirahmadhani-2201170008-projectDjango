from django.shortcuts import render, redirect, get_object_or_404
from .forms import MahasiswaForm, DosenForm, MataKuliahForm
from .models import Mahasiswa, Dosen, MataKuliah
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.contrib.auth.forms import AuthenticationForm

def login_view(request):
    if request.user.is_authenticated:
        return redirect('home')

    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                messages.success(request, f"Selamat datang, {username}!")
                next_url = request.GET.get('next', 'home')
                return redirect(next_url)
            else:
                messages.error(request, "Username atau password salah.")
        else:
            messages.error(request, "Username atau password salah.")
    else:
        form = AuthenticationForm()

    return render(request, 'mahasiswa/login.html', {'form': form})

def logout_view(request):
    logout(request)
    messages.info(request, "Anda telah berhasil logout.")
    return redirect('login')

@login_required(login_url='login')
def input_mahasiswa(request):
    pesan = ""
    if request.method == 'POST':
        form = MahasiswaForm(request.POST)
        if form.is_valid():
            form.save()
            pesan = "Data mahasiswa berhasil disimpan."
            form = MahasiswaForm()
            # Redirect to dashboard if coming from dashboard
            if request.POST.get('from_dashboard'):
                from django.contrib import messages
                messages.success(request, "Data mahasiswa berhasil disimpan.")
                return redirect('home')
    else:
        form = MahasiswaForm()

    semua_mahasiswa = Mahasiswa.objects.all().order_by('id')
    return render(request, 'mahasiswa/input.html', {
        'form': form,
        'pesan': pesan,
        'semua_mahasiswa': semua_mahasiswa,
        'edit_mode': False,
    })

@login_required(login_url='login')
def hapus_mahasiswa(request, id):
    mhs = get_object_or_404(Mahasiswa, id=id)
    mhs.delete()
    # Check if coming from dashboard
    if request.GET.get('from_dashboard'):
        from django.contrib import messages
        messages.success(request, "Data mahasiswa berhasil dihapus.")
        return redirect('home')
    return redirect('input_mahasiswa')

@login_required(login_url='login')
def edit_mahasiswa(request, id):
    mhs = get_object_or_404(Mahasiswa, id=id)

    if request.method == 'POST':
        form = MahasiswaForm(request.POST, instance=mhs)
        if form.is_valid():
            form.save()
            # Check if coming from dashboard
            if request.POST.get('from_dashboard'):
                from django.contrib import messages
                messages.success(request, "Data mahasiswa berhasil diperbarui.")
                return redirect('home')
            return redirect('input_mahasiswa')
    else:
        form = MahasiswaForm(instance=mhs)

    semua_mahasiswa = Mahasiswa.objects.all().order_by('id')
    return render(request, 'mahasiswa/input.html', {
        'form': form,
        'semua_mahasiswa': semua_mahasiswa,
        'edit_mode': True,
        'mahasiswa_id': id,
    })

@login_required(login_url='login')
def input_dosen(request):
    pesan = ""
    if request.method == 'POST':
        form = DosenForm(request.POST)
        if form.is_valid():
            form.save()
            pesan = "Data dosen berhasil disimpan."
            form = DosenForm()
            # Redirect to dashboard if coming from dashboard
            if request.POST.get('from_dashboard'):
                from django.contrib import messages
                messages.success(request, "Data dosen berhasil disimpan.")
                return redirect('home')
    else:
        form = DosenForm()

    semua_dosen = Dosen.objects.all().order_by('id')
    return render(request, 'mahasiswa/input_dosen.html', {
        'form': form,
        'pesan': pesan,
        'semua_dosen': semua_dosen,
        'edit_mode': False,
    })

@login_required(login_url='login')
def hapus_dosen(request, id):
    dosen = get_object_or_404(Dosen, id=id)
    dosen.delete()
    # Check if coming from dashboard
    if request.GET.get('from_dashboard'):
        from django.contrib import messages
        messages.success(request, "Data dosen berhasil dihapus.")
        return redirect('home')
    return redirect('input_dosen')

@login_required(login_url='login')
def edit_dosen(request, id):
    dosen = get_object_or_404(Dosen, id=id)

    if request.method == 'POST':
        form = DosenForm(request.POST, instance=dosen)
        if form.is_valid():
            form.save()
            # Check if coming from dashboard
            if request.POST.get('from_dashboard'):
                from django.contrib import messages
                messages.success(request, "Data dosen berhasil diperbarui.")
                return redirect('home')
            return redirect('input_dosen')
    else:
        form = DosenForm(instance=dosen)

    semua_dosen = Dosen.objects.all().order_by('id')
    return render(request, 'mahasiswa/input_dosen.html', {
        'form': form,
        'semua_dosen': semua_dosen,
        'edit_mode': True,
        'dosen_id': id,
    })

@login_required(login_url='login')
def input_matakuliah(request):
    pesan = ""
    if request.method == 'POST':
        form = MataKuliahForm(request.POST)
        if form.is_valid():
            form.save()
            pesan = "Data mata kuliah berhasil disimpan."
            form = MataKuliahForm()
            # Redirect to dashboard if coming from dashboard
            if request.POST.get('from_dashboard'):
                from django.contrib import messages
                messages.success(request, "Data mata kuliah berhasil disimpan.")
                return redirect('home')
    else:
        form = MataKuliahForm()

    semua_matakuliah = MataKuliah.objects.all().order_by('id')
    return render(request, 'mahasiswa/input_matakuliah.html', {
        'form': form,
        'pesan': pesan,
        'semua_matakuliah': semua_matakuliah,
        'edit_mode': False,
    })

@login_required(login_url='login')
def hapus_matakuliah(request, id):
    mk = get_object_or_404(MataKuliah, id=id)
    mk.delete()
    # Check if coming from dashboard
    if request.GET.get('from_dashboard'):
        from django.contrib import messages
        messages.success(request, "Data mata kuliah berhasil dihapus.")
        return redirect('home')
    return redirect('input_matakuliah')

@login_required(login_url='login')
def edit_matakuliah(request, id):
    mk = get_object_or_404(MataKuliah, id=id)

    if request.method == 'POST':
        form = MataKuliahForm(request.POST, instance=mk)
        if form.is_valid():
            form.save()
            # Check if coming from dashboard
            if request.POST.get('from_dashboard'):
                from django.contrib import messages
                messages.success(request, "Data mata kuliah berhasil diperbarui.")
                return redirect('home')
            return redirect('input_matakuliah')
    else:
        form = MataKuliahForm(instance=mk)

    semua_matakuliah = MataKuliah.objects.all().order_by('id')
    return render(request, 'mahasiswa/input_matakuliah.html', {
        'form': form,
        'semua_matakuliah': semua_matakuliah,
        'edit_mode': True,
        'matakuliah_id': id,
    })

@login_required(login_url='login')
def home(request):
    total_mahasiswa = Mahasiswa.objects.count()
    total_dosen = Dosen.objects.count()
    total_matakuliah = MataKuliah.objects.count()

    # Get data lists for integrated dashboard
    mahasiswa_list = Mahasiswa.objects.all().order_by('-id')
    dosen_list = Dosen.objects.all().order_by('-id')
    matakuliah_list = MataKuliah.objects.all().order_by('-id')

    return render(request, 'mahasiswa/home.html', {
        'total_mahasiswa': total_mahasiswa,
        'total_dosen': total_dosen,
        'total_matakuliah': total_matakuliah,
        'mahasiswa_list': mahasiswa_list,
        'dosen_list': dosen_list,
        'matakuliah_list': matakuliah_list,
    })