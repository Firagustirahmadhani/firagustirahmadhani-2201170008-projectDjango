from django.urls import path
from . import views

urlpatterns = [
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('', views.home, name='home'),
    path('input/', views.input_mahasiswa, name='input_mahasiswa'),
    path('hapus/<int:id>/', views.hapus_mahasiswa, name='hapus_mahasiswa'),
    path('edit/<int:id>/', views.edit_mahasiswa, name='edit_mahasiswa'),
    path('input_dosen/', views.input_dosen, name='input_dosen'),
    path('hapus_dosen/<int:id>/', views.hapus_dosen, name='hapus_dosen'),
    path('edit_dosen/<int:id>/', views.edit_dosen, name='edit_dosen'),
    path('input_matakuliah/', views.input_matakuliah, name='input_matakuliah'),
    path('hapus_matakuliah/<int:id>/', views.hapus_matakuliah, name='hapus_matakuliah'),
    path('edit_matakuliah/<int:id>/', views.edit_matakuliah, name='edit_matakuliah'),
]
