from django.db import models

class Mahasiswa(models.Model):
    nama = models.CharField(max_length=100)
    npm = models.CharField(max_length=20)
    email = models.EmailField()
    no_hp = models.CharField(max_length=15, null=True, blank=True)
    jurusan = models.CharField(max_length=100, blank=True)  # <-- tambah field ini
    alamat = models.TextField(blank=True)  # <-- tambah field ini

    def __str__(self):
        return self.nama

class Dosen(models.Model):
    nama = models.CharField(max_length=100)
    nidn = models.CharField(max_length=20, unique=True)
    email = models.EmailField()
    no_hp = models.CharField(max_length=15, null=True, blank=True)
    alamat = models.TextField(blank=True)
    homebase = models.CharField(max_length=100)

    def __str__(self):
        return self.nama

class MataKuliah(models.Model):
    nama_mk = models.CharField(max_length=100)
    kode_mk = models.CharField(max_length=20, unique=True)
    sks = models.IntegerField()
    semester = models.IntegerField()
    mhs_mk = models.ManyToManyField(Mahasiswa, related_name='mata_kuliah')
    dosen_mk = models.ForeignKey(Dosen, on_delete=models.CASCADE, related_name='mata_kuliah', null=True, blank=True)

    def __str__(self):
        return self.nama_mk