from django import forms
from .models import Mahasiswa, Dosen, MataKuliah

# ✅ Menggunakan ModelForm supaya bisa dipakai untuk tambah & edit data
class MahasiswaForm(forms.ModelForm):
    class Meta:
        model = Mahasiswa
        fields = ['nama', 'npm', 'email', 'no_hp', 'jurusan', 'alamat']
        widgets = {
            'nama': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Masukkan nama mahasiswa'
            }),
            'npm': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Masukkan NPM'
            }),
            'email': forms.EmailInput(attrs={
                'class': 'form-control',
                'placeholder': 'Masukkan email mahasiswa'
            }),
            'no_hp': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Masukkan nomor HP mahasiswa'
            }),
            'jurusan': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Masukkan jurusan mahasiswa'
            }),
            'alamat': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 2,
                'placeholder': 'Masukkan alamat lengkap'
            }),
        }
        labels = {
            'nama': 'Nama Lengkap',
            'npm': 'NPM',
            'email': 'Email',
            'no_hp': 'Nomor HP',
            'jurusan': 'Jurusan',
            'alamat': 'Alamat',
        }

class DosenForm(forms.ModelForm):
    class Meta:
        model = Dosen
        fields = ['nama', 'nidn', 'email', 'no_hp', 'alamat', 'homebase']
        widgets = {
            'nama': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Masukkan nama dosen'
            }),
            'nidn': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Masukkan NIDN'
            }),
            'email': forms.EmailInput(attrs={
                'class': 'form-control',
                'placeholder': 'Masukkan email dosen'
            }),
            'no_hp': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Masukkan nomor HP dosen'
            }),
            'alamat': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 2,
                'placeholder': 'Masukkan alamat lengkap'
            }),
            'homebase': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Masukkan homebase dosen'
            }),
        }
        labels = {
            'nama': 'Nama Lengkap',
            'nidn': 'NIDN',
            'email': 'Email',
            'no_hp': 'Nomor HP',
            'alamat': 'Alamat',
            'homebase': 'Homebase',
        }

class MataKuliahForm(forms.ModelForm):
    class Meta:
        model = MataKuliah
        fields = ['nama_mk', 'kode_mk', 'sks', 'semester', 'dosen_mk', 'mhs_mk']
        widgets = {
            'nama_mk': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Masukkan nama mata kuliah'
            }),
            'kode_mk': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Masukkan kode mata kuliah'
            }),
            'sks': forms.NumberInput(attrs={
                'class': 'form-control',
                'placeholder': 'Masukkan jumlah SKS'
            }),
            'semester': forms.NumberInput(attrs={
                'class': 'form-control',
                'placeholder': 'Masukkan semester'
            }),
            'dosen_mk': forms.Select(attrs={
                'class': 'form-control'
            }),
            'mhs_mk': forms.SelectMultiple(attrs={
                'class': 'form-control'
            }),
        }
        labels = {
            'nama_mk': 'Nama Mata Kuliah',
            'kode_mk': 'Kode Mata Kuliah',
            'sks': 'SKS',
            'semester': 'Semester',
            'dosen_mk': 'Dosen Pengampu',
            'mhs_mk': 'Mahasiswa',
        }