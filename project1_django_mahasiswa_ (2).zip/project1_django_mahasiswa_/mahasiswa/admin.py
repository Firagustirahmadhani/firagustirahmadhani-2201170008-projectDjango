from django.contrib import admin
from .models import Mahasiswa, Dosen, MataKuliah

@admin.register(Mahasiswa)
class MahasiswaAdmin(admin.ModelAdmin):
    list_display = ('id', 'nama', 'npm', 'email', 'jurusan', 'no_hp', 'alamat')
    search_fields = ('nama', 'npm', 'email', 'jurusan','alamat')

@admin.register(Dosen)
class DosenAdmin(admin.ModelAdmin):
    list_display = ('id', 'nama', 'nidn', 'email', 'no_hp', 'alamat', 'homebase')
    search_fields = ('nama', 'nidn', 'email', 'homebase')

@admin.register(MataKuliah)
class MataKuliahAdmin(admin.ModelAdmin):
    list_display = ('id', 'nama_mk', 'kode_mk', 'sks', 'semester')
    search_fields = ('nama_mk', 'kode_mk')
    filter_horizontal = ('mhs_mk',)
